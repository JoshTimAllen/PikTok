﻿using Firebase.Storage;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PikTok.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using PikTok.Services;
namespace PikTok.Controllers {
    public class ProfileController : Controller {
        private readonly AuthService authService;
        private readonly DatabaseService databaseService;
        public ProfileController(AuthService authService, DatabaseService databaseService) {
            this.authService = authService;
            this.databaseService = databaseService;
        }
        [HttpGet]
        public async Task<IActionResult> LoadProfile(string UserName) {
            if (!Request.Cookies.ContainsKey("Token")) {
                return View("cta");
            }
            UserAccount userAccount = await authService.GetUser(Request.Cookies);
            if(UserName == userAccount.profile.UserName) {
                return View("Profile", userAccount);
            }
            return View("Profile", userAccount);
        }
        [HttpPost]
        public async Task<IActionResult> UploadMedia(string UserName, [FromForm] IFormFile ProfilePhoto) {
            if (!Request.Cookies.ContainsKey("Token")) {
                return View("cta");
            }
            UserAccount userAccount = await authService.GetUser(Request.Cookies);

            var stream = ProfilePhoto.OpenReadStream();

            // Constructr FirebaseStorage, path to where you want to upload the file and Put it there
            var task = new FirebaseStorage("jdgs-7e441.appspot.com")
                .Child("data")
                .Child("random")
                .Child("file.png")
                .PutAsync(stream);

            // Track progress of the upload
            task.Progress.ProgressChanged += (s, e) => Console.WriteLine($"Progress: {e.Percentage} %");

            // await the task to wait until upload completes and get the download url
            var downloadUrl = await task;
            return View("Profile", userAccount);
        }
        [HttpPost("Post")]
        public async Task<IActionResult> CreatePost(string Description) {
            if (!Request.Cookies.ContainsKey("Token")) {
                return View("cta");
            }
            UserAccount userAccount = await authService.GetUser(Request.Cookies);
            PostModel post = new PostModel();
            post.ProfilePictureUrl = userAccount.profile.ProfilePicture.url;
            post.userId = userAccount.userId;
            userAccount.posts.Add(post);
            return View("Profile", userAccount);
        }

        [HttpGet]
        public async Task<IActionResult> LoadProfileMedia(string UserName) {
            if (!Request.Cookies.ContainsKey("Token")) {
                return View("cta");
            }
            UserAccount userAccount = await authService.GetUser(Request.Cookies);

            return View("Profile", new ProfileModel() { });
        }
        [HttpGet]
        public async Task<IActionResult> LoadProfileMediaByID(string UserName,string MediaID) {
            if (!Request.Cookies.ContainsKey("Token")) {
                return View("cta");
            }
            UserAccount userAccount = await authService.GetUser(Request.Cookies);

            return View("Profile", new ProfileModel() {  });
        }

        [HttpGet("Post")]
        public async Task<IActionResult> Post() {
            PostModel post = new PostModel();
            post.medias.Add(new Media() { url = "https://firebasestorage.googleapis.com/v0/b/jdgs-7e441.appspot.com/o/UserMedia%2FUser-5ffcc4c6e556ce7f9687d17d%2FProfilePicture?alt=media&token=0555cc49-9ff5-4612-82d3-3b449458aff7" });
            return Ok(post);
        }
    }
}