﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PikTok.Models {
    public class MultiModel {
        public UserAccount userAccount { get; set; }

    }
}
