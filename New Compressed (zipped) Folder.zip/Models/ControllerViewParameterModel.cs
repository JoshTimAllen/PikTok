﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PikTok.Models {
    public class ControllerViewParameterModel {
        public UserAccount userAccount { get; set; }
    }
}
